# DZ MkDocs Template

Este repositorio contiene una configuración mínima lista para desplegar con MkDocs y GitHub Pages.

## Uso

1. Instala las dependencias:

```bash
pip install -r requirements.txt
```

2. Para desarrollo local:

```bash
mkdocs serve
```

3. Para construir y servir estáticamente:

```bash
mkdocs build
cd site
python3 -m http.server
```

## `requirements-local.txt`

Este archivo es opcional y puede usarse para incluir dependencias solo en entorno local.

Instalación:

```bash
pip install -r requirements-local.txt
```

