# DZ MkDocs

Este sitio está generado con [MkDocs](https://www.mkdocs.org/) y publicado automáticamente en GitHub Pages en:  
👉 https://dz-mkdocs.github.io

## Estructura

- `docs/`: Contenido del sitio en Markdown.
- `overrides/`: Personalizaciones del tema (HTML).
- `mkdocs.yml`: Configuración principal del sitio.
- `.github/workflows/gh-pages.yml`: Despliegue automático en GitHub Pages.
- `site/`: Carpeta generada automáticamente al ejecutar `mkdocs build`.

## Cómo levantar el sitio en local

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
mkdocs serve
```

Luego visita `http://127.0.0.1:8000`.

## Cómo desplegar en GitHub Pages

Cada vez que haces push a la rama `main`, GitHub Actions generará y publicará el sitio en la rama `gh-pages`.

## Cambiar de tema

Para usar otro tema (como `readthedocs`):

1. Edita `mkdocs.yml` y reemplaza:
   ```yaml
   theme:
     name: readthedocs
   ```
2. Instala el tema (si no está):
   ```bash
   pip install mkdocs-theme-readthedocs
   ```

## Requisitos

Ver `requirements.txt`.
