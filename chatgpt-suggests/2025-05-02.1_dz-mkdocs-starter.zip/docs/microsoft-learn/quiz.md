# Microsoft Learn - Check your knowledge

Aquí puedes incluir preguntas de repaso tipo examen o trivia para tu estudio.

---

**Pregunta 1**  
¿Cuál es la función de Azure Active Directory en una infraestructura en la nube de Microsoft?

- [ ] Almacenar bases de datos relacionales.  
- [x] Gestionar identidades y accesos.  
- [ ] Proveer servicios de almacenamiento de blobs.  
- [ ] Ejecutar máquinas virtuales de alta disponibilidad.

---

[⬅ Volver a Inicio](../index.md)