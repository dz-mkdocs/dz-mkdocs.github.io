let quizBank = {};
const container = document.getElementById("quiz-container");

async function init() {
  const res = await fetch(new URL('assets/data/quizzes.json', window.location.href));
  quizBank = await res.json();

  quizBank.quizzes.forEach((quiz, quizIndex) => {
    const quizDiv = document.createElement("div");
    container.appendChild(quizDiv);
  });
}

document.addEventListener("DOMContentLoaded", init);
